# Furry Angband Tile Pack

A self-contained visual installer for **Angband 4.2.6 Graphical Furry Races**.
It replaces selected Shockbolt player, monster, item, and dungeon tiles while
leaving every unmapped Angband tile intact.

## Before installing

Open `preview/installed-tiles.png` to see the exact 64x64 art installed by the
pack. The larger concept sheet is in `preview/concept-sheet.png`.

## Install

1. Extract this entire ZIP.
2. Open a terminal in the extracted `Furry-Angband-Tile-Pack` folder.
3. Run:

   `./INSTALL.sh "/path/to/Angband-4.2.6-Graphical-Furry-Races"`

   You can also run `./INSTALL.sh` and paste the Angband folder path when asked.
4. Restart Angband and select **Shockbolt Dark** or **Shockbolt Light** tiles.

The installer makes a one-time backup in
`lib/tiles/shockbolt/furry-pack-backup`. Reinstalling will not overwrite that
original backup.

## Uninstall

Run:

`./UNINSTALL.sh "/path/to/Angband-4.2.6-Graphical-Furry-Races"`

The original Shockbolt image and player mapping file will be restored. The
backup remains available for future use.

## Included replacements

- Players: Fox, Bunny, Ferret, Cat, and Chicken
- Monsters: Wolf, Orc captain, Giant white rat, Killer brown beetle, and Grape jelly
- Items: Long Sword, Wicker Shield, blue potion, Small wooden chest, and Wooden Torch
- Terrain: floor, granite wall, closed door, and down staircase, including lighting variants

## Compatibility

This pack expects the 8192x2048 Shockbolt sheet layout used by the supplied
Angband 4.2.6 graphical build. It does not alter saves, executables, game rules,
race stats, or other tilesets.
