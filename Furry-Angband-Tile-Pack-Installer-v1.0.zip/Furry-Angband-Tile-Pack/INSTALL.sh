#!/usr/bin/env bash
set -Eeuo pipefail

PACK_DIR="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GAME_DIR="${1:-}"

if [[ -z "$GAME_DIR" ]]; then
    printf 'Path to your Angband folder: '
    IFS= read -r GAME_DIR
fi

GAME_DIR="${GAME_DIR%/}"
TILE_DIR="$GAME_DIR/lib/tiles/shockbolt"
BACKUP_DIR="$TILE_DIR/furry-pack-backup"

if [[ ! -f "$TILE_DIR/64x64.png" || ! -f "$TILE_DIR/xtra-shb.prf" ]]; then
    printf 'Error: %s is not an Angband folder with Shockbolt tiles.\n' "$GAME_DIR" >&2
    printf 'Choose the folder containing lib/tiles/shockbolt/64x64.png.\n' >&2
    exit 1
fi

if [[ ! -f "$PACK_DIR/assets/64x64-furry.png" || ! -f "$PACK_DIR/assets/xtra-shb-furry.prf" ]]; then
    printf 'Error: installer assets are missing. Extract the entire ZIP first.\n' >&2
    exit 1
fi

mkdir -p "$BACKUP_DIR"
if [[ ! -f "$BACKUP_DIR/64x64.png" ]]; then
    cp -p "$TILE_DIR/64x64.png" "$BACKUP_DIR/64x64.png"
fi
if [[ ! -f "$BACKUP_DIR/xtra-shb.prf" ]]; then
    cp -p "$TILE_DIR/xtra-shb.prf" "$BACKUP_DIR/xtra-shb.prf"
fi

cp "$PACK_DIR/assets/64x64-furry.png" "$TILE_DIR/.64x64-furry.tmp.png"
cp "$PACK_DIR/assets/xtra-shb-furry.prf" "$TILE_DIR/.xtra-shb-furry.tmp.prf"
mv -f "$TILE_DIR/.64x64-furry.tmp.png" "$TILE_DIR/64x64.png"
mv -f "$TILE_DIR/.xtra-shb-furry.tmp.prf" "$TILE_DIR/xtra-shb.prf"
printf 'Furry Angband Tile Pack installed on %s\n' "$(date)" > "$TILE_DIR/furry-pack-installed.txt"

printf '\nInstalled successfully.\n'
printf 'Restart Angband and select Shockbolt Dark or Shockbolt Light tiles.\n'
printf 'Your originals are backed up in:\n  %s\n' "$BACKUP_DIR"

