#!/usr/bin/env bash
set -Eeuo pipefail

GAME_DIR="${1:-}"

if [[ -z "$GAME_DIR" ]]; then
    printf 'Path to your Angband folder: '
    IFS= read -r GAME_DIR
fi

GAME_DIR="${GAME_DIR%/}"
TILE_DIR="$GAME_DIR/lib/tiles/shockbolt"
BACKUP_DIR="$TILE_DIR/furry-pack-backup"

if [[ ! -f "$BACKUP_DIR/64x64.png" || ! -f "$BACKUP_DIR/xtra-shb.prf" ]]; then
    printf 'Error: no complete Furry Tile Pack backup was found in:\n  %s\n' "$BACKUP_DIR" >&2
    exit 1
fi

cp -p "$BACKUP_DIR/64x64.png" "$TILE_DIR/.64x64-restore.tmp.png"
cp -p "$BACKUP_DIR/xtra-shb.prf" "$TILE_DIR/.xtra-shb-restore.tmp.prf"
mv -f "$TILE_DIR/.64x64-restore.tmp.png" "$TILE_DIR/64x64.png"
mv -f "$TILE_DIR/.xtra-shb-restore.tmp.prf" "$TILE_DIR/xtra-shb.prf"
rm -f "$TILE_DIR/furry-pack-installed.txt"

printf '\nOriginal Shockbolt tiles restored successfully.\n'
printf 'The backup was kept so you can reinstall safely later.\n'

